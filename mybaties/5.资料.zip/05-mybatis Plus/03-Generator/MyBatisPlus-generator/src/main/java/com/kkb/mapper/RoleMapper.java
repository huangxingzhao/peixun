package com.kkb.mapper;

import com.kkb.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 江帅帅 Jss_forever
 * @since 2019-05-08
 */
public interface RoleMapper extends BaseMapper<Role> {

}
