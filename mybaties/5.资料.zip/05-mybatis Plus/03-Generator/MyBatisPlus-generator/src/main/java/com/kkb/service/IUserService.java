package com.kkb.service;

import com.kkb.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 江帅帅 Jss_forever
 * @since 2019-05-08
 */
public interface IUserService extends IService<User> {

}
