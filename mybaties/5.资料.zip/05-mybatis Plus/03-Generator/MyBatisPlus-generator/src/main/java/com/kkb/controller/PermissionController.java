package com.kkb.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 江帅帅 Jss_forever
 * @since 2019-05-08
 */
@RestController
@RequestMapping("/permission")
public class PermissionController {

}

