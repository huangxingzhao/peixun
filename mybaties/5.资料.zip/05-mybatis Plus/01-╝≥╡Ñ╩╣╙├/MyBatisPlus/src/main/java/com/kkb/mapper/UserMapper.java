package com.kkb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kkb.pojo.User;

public interface UserMapper extends BaseMapper<User> {

}
