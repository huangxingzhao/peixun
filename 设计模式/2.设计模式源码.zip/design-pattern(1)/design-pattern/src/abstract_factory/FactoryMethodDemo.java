package abstract_factory;

public class FactoryMethodDemo {

	public static void main(String[] args) {
	}

}
