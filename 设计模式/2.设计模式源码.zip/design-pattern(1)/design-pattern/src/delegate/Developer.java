package delegate;

public class Developer {

	public void development() {
		System.out.println("又来新需求了，开干");
	}
}
