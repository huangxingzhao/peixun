package factory_method.product;

public class Dog  extends Animal{
	public void eat(){
		System.out.println("狗吃骨头");
	}
}
