package factory_method.product;

public class Cat extends Animal{

	public void eat(){
		System.out.println("猫吃老鼠");
	}
}
