package simple_factory.product;

//工厂生产的产品对应的接口或者抽象类
public abstract class Animal {
	abstract void eat();
}
