package com.abc.service;

public interface SomeService {
    void doSome();
}
