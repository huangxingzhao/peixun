package com.abc.service;

public class TwoServiceImpl implements SomeService {
    public void doSome() {
        System.out.println("执行TwoServiceImpl的doSome()");
    }
}
