package com.abc.service;

public class OneServiceImpl implements SomeService {
    public void doSome() {
        System.out.println("执行OneServiceImpl的doSome()");
    }
}
