package com.abc.run;


import org.apache.dubbo.container.Main;
import java.io.IOException;

public class ProviderRun {
    public static void main(String[] args) throws IOException {
        Main.main(args);
    }
}
