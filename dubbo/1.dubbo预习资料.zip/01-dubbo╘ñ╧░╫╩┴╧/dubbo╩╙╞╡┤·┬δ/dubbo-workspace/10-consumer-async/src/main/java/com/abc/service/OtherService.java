package com.abc.service;

public interface OtherService {
    String doFirst();
    String doSecond();
    String doThird();
    String doFourth();
}
