package com.abc.service;


public interface UserService {
    String getUsernameById(int id);
    void addUser(String username);
}
