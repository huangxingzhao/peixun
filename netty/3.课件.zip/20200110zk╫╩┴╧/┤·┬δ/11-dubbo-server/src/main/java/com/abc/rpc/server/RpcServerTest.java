package com.abc.rpc.server;

public class RpcServerTest {
    public static void main(String[] args) {
        // new RpcServer().publish("com.abc.rpc.service");
    }
}
