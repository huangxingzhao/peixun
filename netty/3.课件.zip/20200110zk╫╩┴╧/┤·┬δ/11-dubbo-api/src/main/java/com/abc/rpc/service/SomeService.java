package com.abc.rpc.service;

/**
 * 业务接口
 */
public interface SomeService {
    String hello(String name);
}
