package com.abc.discovery;

public interface ServiceDiscovery {
    String discovery(String servcieName) throws Exception;
}
