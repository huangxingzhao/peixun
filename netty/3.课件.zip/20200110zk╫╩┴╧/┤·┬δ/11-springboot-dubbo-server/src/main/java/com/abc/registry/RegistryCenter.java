package com.abc.registry;

public interface RegistryCenter {
    void register(String serviceName, String serviceAddress);
}
