package com.kkb.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties("some.service")
public class SomeServiceProperties {
    // 读取配置文件中的如下两个属性值
    // some.service.prefix
    // some.service.surfix
    private String prefix;
    private String surfix;
}
