package jvm.methodarea;

public class Test {

}
