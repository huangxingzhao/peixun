package com.abc.bean;

import lombok.Data;

@Data
public class Student {
    private String id;
    private String name;
    private int age;
}
